# Maastricht University - DKE - Bachelor - 1st year - Group 16 - Project 1.2 - Titan's Expedition
26/06/2019

You can find here the code of the program for Titan's Expedition and also the report of this project.

To run the simulation:
* java -jar Group16

Optional arguments:
* java -jar Group16 back
* java -jar Group16 simulation 
* java -jar Group16 simulation back

Members: 
* Jan-Felix De Man (i6201411)
* Selim Gilon (i6192074)
* Gyumin Oh (i6185378)
* Pietro Piccini (i6188338)
* Gianluca Vico (i6183186)
