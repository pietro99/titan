public interface GravityMethod {
    public void calculateForce();
}
